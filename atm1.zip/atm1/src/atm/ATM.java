package atm;


public class ATM {

    
    public static void main(String[] args) {
        new Login().setVisible(true);
    }

}
